<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\HR\\Providers\\HRServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\HR\\Providers\\HRServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);