<?php

return [
    'name' => 'Inventory',
    'description' => 'Products, Categories, Warehouses, and Stock Management for Twinx ERP',
];
