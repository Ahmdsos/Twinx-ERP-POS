<?php

return [
    'name' => 'Core',
    'description' => 'Core module containing shared utilities, contracts, and traits for Twinx ERP',
];
