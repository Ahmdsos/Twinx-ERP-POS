<?php

namespace App\Models;

/**
 * Alias for Modules\Sales\Models\PosShift
 */
class PosShift extends \Modules\Sales\Models\PosShift
{
}
