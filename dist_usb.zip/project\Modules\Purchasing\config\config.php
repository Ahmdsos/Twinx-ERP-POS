<?php

return [
    'name' => 'Purchasing',
    'description' => 'Suppliers, Purchase Orders, GRN, and Purchase Invoices for Twinx ERP',
];
