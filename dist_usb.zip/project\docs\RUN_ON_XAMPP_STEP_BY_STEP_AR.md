# 🖥️ تشغيل Twinx ERP على XAMPP — دليل خطوة بخطوة

> هذا الدليل مخصص للمبتدئين. اتبع كل خطوة بالترتيب.

---

## 📋 المتطلبات

| البرنامج | الحد الأدنى | رابط التحميل |
|---|---|---|
| XAMPP | أي إصدار يدعم PHP 8.2+ | [apachefriends.org](https://www.apachefriends.org/) |
| Composer | v2+ | [getcomposer.org](https://getcomposer.org/download/) |
| Node.js | v18+ | [nodejs.org](https://nodejs.org/) |

---

## الخطوة 1: تثبيت XAMPP

1. حمّل XAMPP من الرابط أعلاه
2. شغّل ملف التثبيت واختر المسار الافتراضي `C:\xampp`
3. أثناء التثبيت، تأكد من اختيار:
   - ✅ Apache
   - ✅ MySQL
   - ✅ PHP
4. بعد التثبيت، افتح **XAMPP Control Panel**

---

## الخطوة 2: تشغيل Apache و MySQL

1. افتح **XAMPP Control Panel**
2. اضغط **Start** بجانب **Apache**
3. اضغط **Start** بجانب **MySQL**
4. تأكد أن كلاهما يظهر بلون **أخضر**

> ⚠️ **لو ظهر خطأ في Apache**: المنفذ 80 مشغول. غيّره من Config → Apache (httpd.conf) → غيّر `Listen 80` إلى `Listen 8080`

---

## الخطوة 3: إنشاء قاعدة البيانات

1. افتح المتصفح واذهب إلى: `http://localhost/phpmyadmin`
2. اضغط على **New** (جديد) في القائمة اليسرى
3. في خانة **Database name** اكتب: `twinx_erp`
4. اختر **Collation**: `utf8mb4_unicode_ci`
5. اضغط **Create**

---

## الخطوة 4: نسخ المشروع

### الطريقة السهلة (سكربت تلقائي):
```
tools\install_to_xampp.bat
```

### الطريقة اليدوية:
1. انسخ مجلد المشروع بالكامل إلى:
   ```
   C:\xampp\htdocs\twinx-erp
   ```
2. افتح **Command Prompt** (أو PowerShell) في مجلد المشروع

---

## الخطوة 5: إعداد ملف البيئة (.env)

1. في مجلد المشروع، ابحث عن `.env.xampp.example`
2. انسخه وسمّه `.env`:
   ```
   copy .env.xampp.example .env
   ```
3. الملف جاهز ولا يحتاج تعديل (إلا لو غيّرت اسم قاعدة البيانات)

---

## الخطوة 6: تثبيت المتطلبات

افتح **Command Prompt** في مجلد المشروع وشغّل الأوامر التالية بالترتيب:

```bash
# 1. تثبيت حزم PHP
composer install

# 2. توليد مفتاح التطبيق
php artisan key:generate

# 3. تشغيل ترحيل قاعدة البيانات + البيانات الأولية
php artisan migrate --seed

# 4. تثبيت حزم Node وبناء الواجهة
npm install
npm run build
```

---

## الخطوة 7: فتح التطبيق

1. افتح المتصفح
2. اذهب إلى: `http://localhost/twinx-erp/public`
3. ستظهر صفحة تسجيل الدخول

---

## الخطوة 8: تسجيل الدخول كمدير

| الحقل | القيمة |
|---|---|
| البريد الإلكتروني | `admin@local.test` |
| كلمة المرور | `Admin@12345` |

---

## 🔧 حل المشاكل الشائعة

### المشكلة: صفحة بيضاء أو خطأ 500
```bash
# تأكد من صلاحيات مجلد storage
# ثم امسح الكاش:
php artisan config:clear
php artisan cache:clear
php artisan view:clear
```

### المشكلة: "SQLSTATE[HY000] [2002] Connection refused"
- تأكد أن MySQL شغّال من XAMPP Control Panel
- تأكد أن اسم قاعدة البيانات في `.env` صحيح: `twinx_erp`

### المشكلة: "Class not found" أو "autoload error"
```bash
composer dump-autoload
```

### المشكلة: الواجهة مش ظاهرة بشكل صحيح
```bash
npm run build
```

### المشكلة: "APP_KEY is missing"
```bash
php artisan key:generate
```

### المشكلة: المنفذ 80 مشغول
- أغلق Skype أو أي برنامج آخر يستخدم المنفذ 80
- أو غيّر منفذ Apache في XAMPP

---

## 📝 ملاحظات مهمة

- **لا تحذف** مجلد `storage` — التطبيق يحتاجه للعمل
- **لا تحذف** ملف `.env` — يحتوي على إعدادات الاتصال
- لو عايز تعمل **إعادة ضبط** للبيانات:
  ```bash
  php artisan migrate:fresh --seed
  ```
  ⚠️ هذا سيحذف كل البيانات ويعيد البيانات الأولية فقط!
