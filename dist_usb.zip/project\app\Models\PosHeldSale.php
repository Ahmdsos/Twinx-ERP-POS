<?php

namespace App\Models;

/**
 * Alias for Modules\Sales\Models\PosHeldSale
 */
class PosHeldSale extends \Modules\Sales\Models\PosHeldSale
{
}
