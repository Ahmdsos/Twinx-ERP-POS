<?php

namespace App\Models;

/**
 * Alias for Modules\Core\Models\ActivityLog
 */
class ActivityLog extends \Modules\Core\Models\ActivityLog
{
}
