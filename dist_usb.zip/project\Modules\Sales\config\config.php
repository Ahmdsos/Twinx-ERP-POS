<?php

return [
    'name' => 'Sales',
    'description' => 'Customers, Sales Orders, Delivery, Invoices, and Receipts for Twinx ERP',
];
