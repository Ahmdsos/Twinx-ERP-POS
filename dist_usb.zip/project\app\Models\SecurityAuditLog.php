<?php

namespace App\Models;

/**
 * Alias for Modules\Core\Models\SecurityAuditLog
 */
class SecurityAuditLog extends \Modules\Core\Models\SecurityAuditLog
{
}
