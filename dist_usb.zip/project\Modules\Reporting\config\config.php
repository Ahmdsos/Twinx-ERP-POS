<?php

return [
    'name' => 'Reporting',
    'description' => 'Financial reports, aging reports, stock reports, and dashboard for Twinx ERP',
];
