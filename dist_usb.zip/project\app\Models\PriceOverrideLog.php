<?php

namespace App\Models;

/**
 * Alias for Modules\Sales\Models\PriceOverrideLog
 */
class PriceOverrideLog extends \Modules\Sales\Models\PriceOverrideLog
{
}
