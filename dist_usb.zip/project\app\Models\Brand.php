<?php

namespace App\Models;

/**
 * Alias for Modules\Inventory\Models\Brand
 */
class Brand extends \Modules\Inventory\Models\Brand
{
}
